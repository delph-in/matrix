cat lexicon_core.tsv   | python generate_lexicon.py 0  > lexicon_core.tdl
cat lexicon_static.tsv | python generate_lexicon.py 20 > lexicon_static.tdl

