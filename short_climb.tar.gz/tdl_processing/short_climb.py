#!/usr/bin/python
import sys
import getopt
import re
import shutil
import tdl
import os

##add versions calling different libraries here:
##key is version name, value is file with definitions
versions = {}

path = '../climb/'
gram_path = '../'




def main():
  # Extract the options and arguments, act on the options, and validate
  # the commands.
  try:
    opts, args = getopt.getopt(sys.argv[1:], 'O:D:bl:',['oldversion=', 'OLDVERSION=', 'dir=','DIR=','backup','libcreation'])

  except getopt.GetoptError, err:
    print str(err)
    usage()

## warn user when no new directory and no back-up was selected.   

  if len(args) < 1:
    usage()
  elif len(opts) == 0:
    check = raw_input('You are not creating a back up, nor placing the new grammar in a separate directory. No output will be created to flip back to the previous version of the grammar. Are you sure you want to continue [Yes/No]?')
    while True:
      if not check in ['Yes','yes','Y','y','No','no','N','n']:
        check = raw_input('Please say \'yes\' or \'no\':')
      else:
        break
  else:
    check = 'no'
    for o, a in opts:
      if o in ['-D','-b','--dir','--DIR','--backup','-l','--libcreation']:
        check = 'yes'
    if check == 'no':
      check = raw_input('You are not creating a back up, nor placing the new grammar in a separate directory. No output will be created to flip back to the previous version of the grammar. Are you sure you want to continue [Yes/No]?')
      while True:
        if not check in ['Yes','yes','Y','y','No','no','N','n']:
          check = raw_input('Please say \'yes\' or \'no\':')
        else:
          break

  if check in ['Yes','yes','Y','y']:
    create_mod_grammar(args[0], opts)


'''Read in modifications and apply them to the correct files'''
def create_mod_grammar(version, opts):
  if version in versions:
    myfiles = versions.get(version)
  else:
    myfiles = version.split(',')
  
  outpath = ''
  libname = ''
  rev_output = False
  for o, a in opts:
    if o in ('-O','--oldversion','--OLDVERSION'):
      rev_output = True
      outfile = a
    if o in ('-D','--dir','--DIR'):
      outpath = a
      if not '../' in outpath:
        outpath = '../../' + outpath
      elif not '../../' in outpath:
        outpath = '../' + outpath
      if not outpath[-1] == '/':
        outpath = outpath + '/'
      ensure_dir(outpath)
    if o in ('-l','--libcreation'):
      libname = a
      

  inputfiles = []
  changes = [{}, {}, {}, [], inputfiles]
  outfiles = []
  for f in myfiles:
    f = path + f
    if rev_output:
      if outfile == '':
        outfile = path + f + '-reverse'
      else:
        outfile = path + outfile
    else:
      outfile = '' 
    changes = process_mod_file(f,inputfiles,changes,outfile,outpath,libname)
    if not outfile == '':
      outfiles.append(outfile)

  inputfiles = changes[4]
  for in_f in inputfiles:
    my_f = gram_path + in_f
    process_tdl_files(my_f, changes,opts,outfiles,outpath,libname)

  if outpath:
    for subdir, dirs, files in os.walk(gram_path):
       for d in dirs:
         if not 'climb' in d:
           new_d = outpath + d
           if not os.path.exists(new_d):
             shutil.copytree('../' + d, new_d)
       for my_f in files:
         if not my_f in inputfiles and os.path.exists(gram_path + my_f):
           shutil.copy(gram_path + my_f, outpath)



'''process file with modifications and stores definitions, creates flip back-up file'''
def process_mod_file(f,inputfiles, changes, outfile, outpath,libname=''):
  myf = open(f, 'r')

  comment = ''
  current_type = ''
  location = False
##maps type name to remove plus boolean whether to remove is addendum or not
  removals = changes[0]
##maps location (typename above which type should be inserted) to new type
  additions = changes[1]
##maps type name to set of new definitions, and boolean value complete or not
  modifications = changes[2]
  rem_comments = changes[3]
  output = False
  if not outfile == '':
    if outpath and '../' in outfile:
      my_outfile = outpath + outfile.split('../').pop()
    else:
      my_outfile = outpath + outfile
    ensure_f_dir(my_outfile)
    myo = open(my_outfile, 'w')
    output = True
  new_lib = False
  if not libname == '':
    if outpath:
      if not '/climb/' in outpath:
        suffix = 'climb/'
      else:
        suffix = ''
      my_new_lib = outpath + suffix + libname
      if 'climb/' in f:
        suffix = ''
      my_old_lib = outpath + suffix + f.split('../').pop()
    else:
      my_new_lib = 'climb/' + libname
      if not 'climb/' in f:
        my_old_lib = 'climb/' + f
      else:
        my_old_lib = f
    ensure_f_dir(my_new_lib)
    ensure_f_dir(my_old_lib)
    myl = open(my_new_lib, 'w')
    myol = open(my_old_lib, 'w')
    new_lib = True
     
  for line in myf:
    if '-;' in line:
      old_comment = line.replace('-;', '')
      rem_comments.append(old_comment)
    elif ';' in line:
      comment += line
      if output:
        if not 'end;' in line:
          myo.write('-;' + line)
        else:
          myo.write(line)
      if new_lib:
        myol.write(line)
        if 'end;' in line:
          myl.write(line)
    elif '=' in line and not ':' in line:
      if 'location' in line:
        location = line.split('=')[1].rstrip()
      elif 'remove' in line:
        removal = line.split('=')[1].rstrip()
        if ',addendum' in removal:
          removal = removal.split(',')[0]
          removals[removal] = [True,comment]
          if output:
            myo.write(removal + ' :+ \n')
          if new_lib:
            myl.write(removal + ' :+ \n')
        else:
          removals[removal] = [False,comment]
          if output:
            myo.write(removal + ' := \n')
          if new_lib:
            myl.write(removal + ' := \n')
        comment = ''
      elif 'complete' in line:
        complete = True
      if 'input=' in line:
        infile = line.split('=')[1]
        infile = infile.rstrip()
        inputfiles.append(infile)
        if output:
          myo.write(line)
        if new_lib:
          myl.write(line + '\n')
          myol.write(line + '\n')
    else:
      if not line == '\n':
        line = re.sub( r';.*', '', line )
        current_type += line
      if end_of_typedef(line, current_type):
        if len(location) > 0:
          if location in additions:
            val = additions[location]
            val[0] = val[0] + comment
            val.append(current_type)
          else:
            val = [comment, current_type]  
          additions[location] = val
          if output:
            my_tname = current_type.split(':')[0].rstrip()
            myo.write('remove=' + my_tname + '\n\n')
          if new_lib:
            myol.write('location=' + location + '\n')
            myol.write(current_type + '\n')
        else:
          typename = current_type.split(':')[0].rstrip()
          typename = typename.lstrip()
          if typename in modifications and not complete:
            value = modifications[typename]
            newcom = value[0] + comment
            value[0] = newcom
          else:
            value = [comment, complete]
          value.append(current_type)
          modifications[typename] = value
          if output:
            if not complete:
              if ':=' in current_type:
                rev_type = current_type.replace(':=', ':-')
              elif ':+' in current_type:
                rev_type = current_type.replace(':+', ':-')
              elif ':-' in current_type:
                rev_type = current_type.replace(':-', ':')
              myo.write(rev_type + '\n')
            else:
              myo.write('complete=on\n')
              my_tname = current_type.split(':')[0].rstrip()
              myo.write(my_tname + '\n')
          if new_lib:
            if not ':-' in current_type:
              myol.write(current_type + '\n')
            else:
              myl.write(current_type.replace(':-',':') + '\n')
        location = ''
        comment = ''
        current_type = ''
        complete = False
  myf.close()
  if output:
    myo.close()
  if libname:
    myl.close()
    myol.close()
  changes = [ removals, additions, modifications, rem_comments, inputfiles ]


  return changes



'''go through tdl files and apply changes, complete substitutions where necessary'''  
def process_tdl_files(f, changes, opts, outfiles, outpath, libname=''):
  removals = changes[0]
  additions = changes[1]
  modifications = changes[2]
  rem_comments = changes[3]

  for o, a in opts:
    if o in ['-b', '--backup']:
      shutil.copy(f, f+'-bak') 

  input_file = open(f,'r')
  
  if outpath:
    if '../' in f:
      nf = outpath + f.split('../').pop() 
    else:
      nf = outpath + f
  else:
    nf = f

  mytdl =  tdl.TDLfile(nf)

  if libname:
    if outpath:
      if '../' in f:
        libcore = outpath + 'climb/core-' + f.split('../').pop() 
      else:
        libcore = outpath + 'climb/core-' + f
      new_libn = outpath + 'climb/' + libname
    else:
      new_libn = 'climb/' + libname
      if '../' in f:
        libcore = ''
        for p in f.split('../'):
          if not p == f.split('../')[-1]:
            libcore = libcore + 'core-' + p + '../'
          else:
            libcore = libcore + 'climb/core-' + p
      else:
        libcore = 'climb/' + f 
    libtdl = tdl.TDLfile(libcore)
    ensure_f_dir(new_libn)
    outfiles.append(new_libn)
   
  current_type = ''
  type_name = ''
  complete = False
  needs_locdef = ''
  flag = 0

  for line in input_file:
    flag = partOfComment(line, flag)
    if ';' in line or line == '\n' or flag == 1:
      if not line in rem_comments:
        mytdl.add_literal(line.rstrip())
        if libname:
          libtdl.add_literal(line.rstrip())
    else:
      line = re.sub( r';.*', '', line )
      current_type += line
      if ':' in line and needs_locdef:
#do library creation
        insert_location_def(outfiles, needs_locdef, line)
        needs_locdef = '' 
      if end_of_typedef(line, current_type):
        reduced_type = False
        type_name = current_type.split(':')[0].rstrip()
        type_name = type_name.lstrip()
        if type_name in additions:
          c1 = additions[type_name].pop(0)
          mytdl.add_literal(c1)
          for nt in additions[type_name]:
            mytdl.add(nt)
            mytdl.add_literal('\n')
          del additions[type_name]
        if type_name in modifications:
          mods = modifications[type_name]
          c2 = mods.pop(0)
          complete = mods.pop(0)
          for m in mods:
            if not ':-' in m:
              mytdl.add(m, c2)
            else:
              my_mods = create_minus_type(m, current_type)
#if library creation make sure it goes well...
              if len(outfiles) > 0:
                insert_operator_reverted_file(type_name, current_type, outfiles)
              if reduced_type:
                modified_type = identify_retainables(modified_type, my_mods) 
              else:
                ct = tdl.TDLparse(current_type)
                my_c = ct.convert_to_string()
                modified_type = identify_retainables(ct, my_mods)
                reduced_type = True
              my_mod = modified_type.convert_to_string()
        if type_name in removals:
#if addendum is specified, original typedef should remain
          if removals[type_name][0] and not ':+' in current_type:
            if reduced_type:
              mytdl.add(my_mod)
            else:
              mytdl.add(current_type)
#if libraries make sure all goes well
          elif len(outfiles) > 0:
            insert_typedef_in_revert(type_name, current_type, outfiles, complete)
            needs_locdef = type_name
        elif not complete:
          if reduced_type:
            mytdl.add(my_mod)
            if libname:
              libtdl.add(my_mod)
          else:
            mytdl.add(current_type)
            if libname:
              libtdl.add(current_type)
#if libraries all goes well
        elif len(outfiles) > 0:
          insert_typedef_in_revert(type_name, current_type, outfiles, complete)
        current_type = ''
        complete = False
        type_name = ''

  if libname:
    libtdl.save()

  mytdl.save()


'''create interpretable tdl structure based on minus definition.'''
def create_minus_type(m, current_type):
  if ':=' in current_type:
    mod_type = m.replace(':-',':=')
  else:
    mod_type = m.replace(':-',':+')
  mods = tdl.TDLparse(mod_type)
  return mods


'''identify which parts of the original structure should be maintained.'''
def identify_retainables(oldt, mods):
  old_str = oldt.convert_to_string()
  new_t = tdl.TDLelem_typedef(oldt.type, oldt.op)
  mychild = tdl.TDLelem_conj()

  old_sts = retrieve_supertypes(oldt)
  removable_sts = retrieve_supertype_names(mods)
  for ost in old_sts:
    if ost.type not in removable_sts:
      mychild.child.append(ost)

  old_constraints = retrieve_constraints(oldt.child[0])
  removable_csts = retrieve_constraints(mods.child[0])

  my_feat_tdl = tdl.TDLelem_feat()
  for oc in old_constraints.iterkeys():
    if oc not in removable_csts:
      my_av_tdl = tdl.TDLelem_conj()
      my_av_tdl.child.append(old_constraints[oc][0])
      my_feat_tdl.child.append(my_av_tdl)
    else:
      o_av = old_constraints[oc][0]
      rem_av = removable_csts[oc][0]
      children = {}
      my_differences = compare_avs(o_av, rem_av)
      if len(my_differences[0]) != 0 or len(my_differences[1]) != 0:
        my_conj = tdl.TDLelem_conj()
        my_av_tdl = tdl.TDLelem_av(oc)
        my_c = tdl.TDLelem_conj()
        for dt in my_differences[0]:
          my_c.child.append(dt)
        for dav in my_differences[1].iterkeys():
          my_av = my_differences[1][dav]
          if not dav == 'my-diff-lists':
            my_f = tdl.TDLelem_feat()
            my_f.child.append(my_av)
          else:
            my_f = my_av
          my_c.child.append(my_f)
        my_av_tdl.child.append(my_c)
        my_conj.child.append(my_av_tdl)
        my_feat_tdl.child.append(my_conj)
  mychild.child.append(my_feat_tdl)
  new_t.child.append(mychild)

  return new_t


'''compares attribute value structures'''
def compare_avs(av1, av2):
  types = []
  avs = {}
  type_names2 = []
  avs2 = {}
  dlists2 = []
  for c2 in av2.child[0].child:
    if isinstance(c2, tdl.TDLelem_type):
      type_names2.append(c2.type)
    elif isinstance(c2, tdl.TDLelem_feat):
      for fc2 in c2.child:
        avs2[fc2.attr] = fc2
    elif isinstance(c2, tdl.TDLelem_dlist):
      dlists2.append(c2) 

  m_chs = False
  if len(av1.child[0].child) > 1:
    m_chs = True

  for c1 in av1.child[0].child:
    if isinstance(c1, tdl.TDLelem_type):
      if not c1.type in type_names2:
        types.append(c1)
    elif isinstance(c1, tdl.TDLelem_feat):
      for fc1 in c1.child:
        if not fc1.attr in avs2:
          avs[fc1.attr] = fc1
        else:
          my_differences = compare_avs(fc1, avs2[fc1.attr])
    elif isinstance(c1, tdl.TDLelem_dlist):
      if len(dlists2) < 1:
        print 'Error: problem in syntax modifying dlist'
      else:
        new_dl = compare_dlists(c1, dlists2[0])
        avs['my-diff-lists'] = new_dl    

  return [types, avs]




'''compare 2 tdl definitions '''
def compare_feature_structures(c1, c2):
  mod_fcs = tdl.TDLelem_feat()
  my_fc2s = {}
  for fc2 in c2.child:
    my_fc2s[fc2.attr] = fc2
  
  for fc1 in c1.child:
    if fc1.attr not in my_fc2s:
      mod_fcs.child.append(fc1)
    else:
      fc2 = my_fc2s.get(fc1.attr)
      if len(fc1.child) == len(fc2.child):
        if len(fc1.child) == 1:
          if isinstance(fc1.child[0], tdl.TDLelem_type):
            if isinstance(fc2.child[0], tdl.TDLelem_type):
              if not fc1.child[0].type == fc2.child[0].type:
                mod_fcs.child.append(fc1)
            else:
              mod_fcs.child.append(fc1)
          elif isinstance(fc1.child[0], tdl.TDLelem_feat):
            if isinstance(fc2.child[0], tdl.TDLelem_feat):
              new_fcs = compare_feature_structures(fc1.child[0], fc2.child[0])
              new_fc = tdl.TDLelem_conj()
              new_fc.child.append(new_fcs)
              mod_fcs.child.append(new_fc) 
            else:
              mod_fcs.child.append(fc1)
          elif isinstance(fc1.child[0], tdl.TDLelem_dlist):
            if isinstance(fc2.child[0], tdl.TDLelem_dlist):
              compare_dlists(fc2.child[0],fc2.child[0])
            else:
              mod_fcs_child.append(fc1)
        else:
          print 'Error: uncommon structure for tdl object'
      else:
        print 'Error: problem in comparative feature structure'

  return mod_fcs


'''retrieve constraint from tdl definition'''
def retrieve_constraints(mytype):
  avs = {}
  for c in mytype.child:
    if isinstance(c, tdl.TDLelem_feat):
      avs.update(process_tdl_feature(c))
  return avs


'''interpret properties in tdl definition'''
def process_tdl_feature(tdl_feat):
  my_avs = {}
  for c in tdl_feat.child:
    if isinstance(c, tdl.TDLelem_av):
      attribute = c.attr
      myvals = []
      myvals.append(c)
      for t_conj in c.child: 
        for gc in t_conj.child:
          if isinstance(gc, tdl.TDLelem_type):
            myvals.append(gc.type)
          elif isinstance(gc, tdl.TDLelem_feat):
            new_val = process_tdl_feature(gc) 
            myvals.append(new_val)
      my_avs[attribute] = myvals 
  return my_avs


'''retrieve supertypes'''
def retrieve_supertypes(mytype):
  supertypes = []
  for c in mytype.child:
    for gc in c.child:
      if isinstance(gc, tdl.TDLelem_type): 
        supertypes.append(gc)
  return supertypes


'''returns names supertypes of a type definition'''
def retrieve_supertype_names(mytype):
#always third generation (grandchild)
  supertypes = []
  for c in mytype.child:
    for gc in c.child:
      if isinstance(gc, tdl.TDLelem_type): 
        supertypes.append(gc.type)
  return supertypes


'''compare difference lists'''
def compare_dlists(dl1, dl2):
  modified_dlist = tdl.TDLelem_dlist()
  if len(dl1.child) != len(dl2.child):
    print 'Error: to change the number of elements in a diff-list, you can either\n a) use the option replace to redefine the complete type\n b) remove the dlist completely using :- and add the new one using := or :+.'
    dlc = None
  else:
    if len(dl1.child) == 1:
      dlc = tdl.TDLelem_conj()
      compare_dlist_items(dl1[0], dl2[0], dlc)
      modified_dlist.child.append(dlc)
    for x in range(0, len(dl1.child)):
      c1 = dl1.child[x]
      c2 = dl2.child[x]
      dlc = tdl.TDLelem_conj()
      compare_dlist_items(c1, c2, dlc)
      modified_dlist.child.append(dlc)
 
  return modified_dlist


'''function that compares items on a difference lists.'''
def compare_dlist_items(c1, c2, dlc):
  if len(c1.child) == len(c2.child):
    if len(c1.child) == 1:
      compare_element_indlist(c1.child[0], c2.child[0], dlc) 
    else:
      for y in range(0, len(c1.child)):
        compare_element_indlist(c1.child[y], c2.child[y], dlc)
  else:
    for gc1 in c1.child:
      if isinstance(gc1, tdl.TDLelem_type):
        for gc2 in c2.child:
          if isinstance(gc2, tdl.TDLelem_type):
            both_types = True
            if gc2.type == gc1.type:
              dlc.child.append(tdl.TDLelem_feat())
            else:
              dlc.child.append(gc1)
          else:
            dlc.child.append(gc1)
      elif isinstance(gc1, tdl.TDLelem_feat): 
        for gc2 in c2.child:
          if isinstance(gc2, tdl.TDLelem_feat): 
            new_fc = compare_feature_structures(gc1, gc2)
            remove_empty_fs(dlc)
            dlc.child.append(new_fc)
          else:
            remove_empty_fs(dlc)
            dlc.child.append(gc1)


'''if a fs is empty, it has no impact on the revision'''
def remove_empty_fs(dlc):
  if len(dlc.child) > 0:
    c = dlc.child.pop()
    if isinstance(c, tdl.TDLelem_feat) and len(c.child) == 0:
      return dlc
    else:
      dlc.child.append(c)
      return dlc
  else:
    return dlc


'''comparing two elements on a difference lists'''
def compare_element_indlist(c1, c2, dlc):
  if isinstance(c2, tdl.TDLelem_feat) and len(c2.child) == 0:
    dlc.child.append(c1)
  elif isinstance(c1, tdl.TDLelem_type):
    if not isinstance(c2, tdl.TDLelem_type):
      dlc.child.append(c1)
    else:
      if c1.type != c2.type:
        dlc.child.append(c1)
      else:
#if type is removed, the new list will get an underspecified element in its
#place (feature structure with no children....)
        dlc.child.append(tdl.TDLelem_feat())
  elif isinstance(c1, tdl.TDLelem_feat):
    if not isinstance(c2, tdl.TDLelem_feat):
      dlc.child.append(c1)
    else:
      new_fc = compare_feature_structures(c1, c2)
      dlc.child.append(new_fc)


'''returns through if line is end of a type definition'''
def end_of_typedef(line, current_type):
  end_mark = re.compile('\.\W') #\.(^\w)
  end = False
  if end_mark.findall(line):
    end = True
  return end
  

'''returns true if current location is part of comment'''
def partOfComment(line, flag):
  if re.match('\s*\#\|', line):
            #multiline comment starts
    flag = 1
  elif re.match('.*\|\#', line):
    flag = 0

  return flag


'''insert typedefinition of previously removed types'''
def insert_typedef_in_revert(type_name, current_type, outfiles, complete=False):
  for of in outfiles:
    my_in = open(of, 'r')
    my_out = open(of + '-temp', 'w')
    for line in my_in:
      if not type_name in line:
        my_out.write(line)
      else:
        if 'location=' in line:
          my_out.write(line)
        elif ':' in line:
          current_type = current_type.lstrip()
          if line.split(':')[0] == current_type.split(':')[0]:
            if ':=' in line:
              if ':=' in current_type:
                my_out.write(current_type + '\n')
            elif ':+' in line:
              if ':+' in current_type:
                my_out.write(current_type + '\n')
          else:
            my_out.write(line)
        else:
          if line.rstrip() == current_type.split(':')[0].rstrip():
            my_out.write(current_type + '\n')
          else:
            my_out.write(line)
    my_in.close()
    my_out.close()
    shutil.move(of + '-temp', of)


'''insert the original operator for previously removed types or types where properties are removed'''
def insert_operator_reverted_file(type_name, current_type, outfiles):
  for of in outfiles:
    my_in = open(of, 'r')
    my_out = open(of + '-temp', 'w')
    for line in my_in:
      if not type_name in line:
        my_out.write(line)
      else:
        if ':=' in current_type and not ':=' in line:
          my_out.write(line.replace(':', ':='))
        elif ':+' in current_type and not ':+' in line:
          my_out.write(line.replace(':', ':+'))
        else:
          my_out.write(line)
    my_in.close()
    my_out.close()
    shutil.move(of + '-temp', of)


'''inserts the location for types that need to be reinserted'''
def insert_location_def(outfiles, needs_locdef, line):
  loc = line.split(':')[0].rstrip()
  for of in outfiles:
    my_in = open(of, 'r')
    my_out = open(of + '-temp', 'w')
    for myl in my_in:
      if needs_locdef in myl and ':' in myl:
        my_out.write('location=' + loc + '\n')
      my_out.write(myl)
    my_in.close()
    my_out.close()
    shutil.move(of + '-temp', of)


'''create directory if does not exist'''
def ensure_f_dir(f):
  d = os.path.dirname(f)
  if not os.path.exists(d):
    os.makedirs(d)


'''create new directory if does not already exist'''
def ensure_dir(d):
  if not os.path.exists(d):
    os.makedirs(d)



def usage():
  """
  Print an appropriate usage message and exit.
  """
  indent = 0
  # if the user asks for help for an invalid command, nothing will be printed,
  # so we catch this with a flag.
  something_printed = False
  # Collect and print examples at the end
  examples = []
  def p(msg, nobreak=False):
    """ Print the message with necessary indentation and linebreaks. """
    if nobreak:
      print " " * indent + msg,
    else:
      print " " * indent + msg

  p("Usage: tdlmod.py [OPTION] INPUT VERSION", nobreak=True)


if __name__ == '__main__':
  main()
